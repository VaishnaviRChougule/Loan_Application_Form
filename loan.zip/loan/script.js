
document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('loanForm');
  const loanAmountInput = document.getElementById('loanAmount');
  

  form.addEventListener('submit', function (event) {
    if (!validateForm()) {
      event.preventDefault();
    }
  });


  function validateForm() {
    const fullNameInput = document.getElementById('fullName');
    const emailInput = document.getElementById('email');
    const panInput = document.getElementById('pan');

    const fullNameRegex = /^[a-zA-Z ]+$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;

    if (!fullNameRegex.test(fullNameInput.value) || fullNameInput.value.split(' ').filter(word => word.length >= 4).length < 2) {
      alert('Please enter a valid full name with at least two words, each with a minimum of four characters.');
      return false;
    }

    if (!emailRegex.test(emailInput.value)) {
      alert('Please enter a valid email address.');
      return false;
    }

    if (!panRegex.test(panInput.value)) {
      alert('Please enter a valid PAN in the format ABCDE1234F.');
      return false;
    }

    return true;
  }

  
  });

  function convertToWords() {
    var inputAmount = document.getElementById('loanAmount').value;
    var amountInWords = convertNumberToWords(inputAmount);
    document.getElementById('amountInWords').innerText = 'Amount in Words: ' + amountInWords + ' Rs.';
  }



  function convertNumberToWords(n) {
    if (n < 0)
      return false;
	 single_digit = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
	 double_digit = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen']
	 below_hundred = ['Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']
	if (n === 0) return 'Zero'
	function translate(n) {
		word = ""
		if (n < 10) {
			word = single_digit[n] + ' '
		}
		else if (n < 20) {
			word = double_digit[n - 10] + ' '
		}
		else if (n < 100) {
			rem = translate(n % 10)
			word = below_hundred[(n - n % 10) / 10 - 2] + ' ' + rem
		}
		else if (n < 1000) {
			word = single_digit[Math.trunc(n / 100)] + ' Hundred ' + translate(n % 100)
		}
		else if (n < 1000000) {
			word = translate(parseInt(n / 1000)).trim() + ' Thousand ' + translate(n % 1000)
		}
		else if (n < 1000000000) {
			word = translate(parseInt(n / 1000000)).trim() + ' Million ' + translate(n % 1000000)
		}
		else {
			word = translate(parseInt(n / 1000000000)).trim() + ' Billion ' + translate(n % 1000000000)
		}
		return word
	}
	 result = translate(n) 
	return result.trim()+'.'
}


function isNumber(evt) {
    var iKeyCode = (evt.which) ? evt.which : evt.keyCode
if ( iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
return false;

return true;


}   